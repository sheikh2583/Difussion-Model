# Latent CelebA blocker decisions

Date: 2026-09-21

## Superseded 8×8 latent U-Net concern

The factor-8 SD VAE failed the local reconstruction gate (rFID 16.153, PSNR
22.32 dB) and was rejected. The operator selected the face-specific frozen
CelebA-HQ VQ-f4 codec instead. Its primary representation is `3×16×16`, so the
four-stage `[1,2,2,2]` backbone now downsamples `16→8→4→2`; it no longer has a
`1×1` bottleneck.

The table below records the proposal measured on 2026-09-21. It was useful for
rejecting the factor-8 SD representation, but it was later superseded before
the completed latent suite.

| Model | Input | Channel multipliers | Bottleneck | Parameters | CPU shape check |
|---|---:|---|---:|---:|---|
| Proposed VQ latent | `3×16×16` | `[1,2,2,2]` | `2×2` | 8,947,459 | passed, output `3×16×16` |
| CelebA pixel | `3×64×64` | `[1,2,2,2]` | `8×8` | 8,947,459 | passed, output `3×64×64` |
| Rejected SD latent | `4×8×8` | `[1,2,2,2]` | `1×1` | 8,948,612 | historical only |

That proposal would have parameter-matched pixel and latent models because both
used the same channels and stage widths.

## Superseding completed-run configuration

The authoritative completed configs and JSONL rows show that the actual latent
suite used `base_channels=128`, channel multipliers `[1,2,2]`, and 24,026,627
backbone parameters. Its path is `16→8→4`. CelebA pixel retained
`base_channels=64`, `[1,2,2,2]`, and 8,947,459 parameters with a
`64→32→16→8` path.

**Final recorded decision:** retain the configs that produced the measured
artifacts. The latent migration reduces boundary state size by 16× but widens
the trainable backbone by about 2.69×. Every pixel-versus-latent comparison must
report this capacity change alongside the codec and spatial-compute changes.
