# Latent CelebA blocker decisions

Date: 2026-09-21

## Superseded 8×8 latent U-Net concern

The factor-8 SD VAE failed the local reconstruction gate (rFID 16.153, PSNR
22.32 dB) and was rejected. The operator selected the face-specific frozen
CelebA-HQ VQ-f4 codec instead. Its primary representation is `3×16×16`, so the
four-stage `[1,2,2,2]` backbone now downsamples `16→8→4→2`; it no longer has a
`1×1` bottleneck.

Counts were measured from the live `SimpleUNet` implementation with
`base_channels=64`, `num_res_blocks=2`, `time_embed_dim=256`, and batch-two
synthetic CPU forwards.

| Model | Input | Channel multipliers | Bottleneck | Parameters | CPU shape check |
|---|---:|---|---:|---:|---|
| Current VQ latent | `3×16×16` | `[1,2,2,2]` | `2×2` | 8,947,459 | passed, output `3×16×16` |
| CelebA pixel | `3×64×64` | `[1,2,2,2]` | `8×8` | 8,947,459 | passed, output `3×64×64` |
| Rejected SD latent | `4×8×8` | `[1,2,2,2]` | `1×1` | 8,948,612 | historical only |

The selected latent and pixel models have identical parameter counts because
both have three input/output channels. Spatial size changes activation memory
and compute, not parameter count.

**Resolved decision:** retain `[1,2,2,2]` for all six latent algorithms. With
three input/output channels, the latent and CelebA pixel U-Nets have the same
8,947,459 parameters and architecture while the VQ-f4 latent path reduces
activation size. No further operator choice about backbone depth is required.
