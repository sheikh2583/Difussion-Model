"""
Common evaluation pipeline. Does not need to know which algorithm
produced the images — it only consumes algorithm.sample() output via
the Sampler, plus the cached real-data reference statistics.
"""
import json
import os
import re
from typing import List

import torch
from torch.utils.data import DataLoader

from config.config import ExperimentConfig
from evaluation.metrics import (
    cache_real_images,
    compute_fid_from_prepared,
    compute_inception_score,
    load_real_images,
    prepare_fid,
)
from sampling.sampler import Sampler
from utils.results import ResultRecord, ResultsWriter
from utils.timing import timer, peak_gpu_memory_mb, reset_peak_gpu_memory
from utils.plots import (
    plot_fid_vs_nfe,
    plot_fid_vs_sampling_time,
    plot_gpu_memory_comparison,
    plot_is_vs_nfe,
    plot_loss_vs_epoch,
    plot_sampling_time_vs_nfe,
    plot_training_time_comparison,
)


def _fid_reference_meta_path(cache_path: str) -> str:
    return cache_path + ".meta.json"


def ensure_fid_reference(cfg: ExperimentConfig, real_loader: DataLoader,
                          device: torch.device) -> str:
    """
    Computes (once) and caches FID reference statistics from real data,
    so every algorithm's evaluation reuses the exact same reference —
    never recomputed per run.

    A small metadata file is cached alongside the stats (image count,
    resolution, channels) and checked on every reuse. If a later run
    requests a reference set with different settings but happens to
    point at the same cache path, this raises explicitly rather than
    silently comparing FID against a mismatched reference distribution.
    """
    cache_path = cfg.evaluation.fid_reference_cache
    meta_path = _fid_reference_meta_path(cache_path)

    expected_meta = {
        "num_images": cfg.evaluation.num_generated_samples,
        "image_size": cfg.dataset.image_size,
        "channels": cfg.backbone.in_channels,
    }

    if os.path.exists(cache_path):
        if not os.path.exists(meta_path):
            raise RuntimeError(
                f"FID reference cache '{cache_path}' exists but its metadata "
                f"file '{meta_path}' is missing, so it cannot be validated as "
                f"matching the current config. Delete the stale cache file "
                f"and re-run, or restore its metadata file."
            )
        with open(meta_path, "r") as f:
            cached_meta = json.load(f)
        if cached_meta != expected_meta:
            raise RuntimeError(
                f"FID reference cache '{cache_path}' was built with "
                f"{cached_meta} but the current run requests {expected_meta}. "
                f"Reusing it would silently bias the FID comparison. Use a "
                f"different `evaluation.fid_reference_cache` path per "
                f"resolution/sample-count setting, or delete the stale cache."
            )
        return cache_path

    real_batches = []
    n_needed = cfg.evaluation.num_generated_samples
    n_collected = 0
    for images, _ in real_loader:
        real_batches.append(images)
        n_collected += images.shape[0]
        if n_collected >= n_needed:
            break

    if n_collected < n_needed:
        raise RuntimeError(
            f"Requested {n_needed} real reference images for FID, but the "
            f"dataset only provided {n_collected}. Reduce "
            f"evaluation.num_generated_samples or provide a larger reference "
            f"split rather than silently evaluating against fewer images."
        )

    real_images = torch.cat(real_batches, dim=0)[:n_needed]

    cache_real_images(real_images, cache_path)
    os.makedirs(os.path.dirname(meta_path), exist_ok=True)
    with open(meta_path, "w") as f:
        json.dump(expected_meta, f, indent=2)
    return cache_path


class Evaluator:
    def __init__(self, cfg: ExperimentConfig, run_dir: str, device: torch.device):
        self.cfg = cfg
        self.run_dir = run_dir
        self.device = device
        run_name = os.path.basename(os.path.normpath(run_dir))
        self.results = ResultsWriter(run_dir, run_name)

    def evaluate(self, sampler: Sampler, nfe_values: List[int],
                 make_plots: bool = False,
                 checkpoint_path: str = None,
                 current_epoch: int = None) -> None:
        if current_epoch is None and checkpoint_path:
            match = re.search(r"epoch(\d+)", str(checkpoint_path))
            current_epoch = int(match.group(1)) if match else None
        real_images = None
        fid_metric = None
        if "fid" in self.cfg.evaluation.metrics:
            real_images = load_real_images(
                self.cfg.evaluation.fid_reference_cache, torch.device("cpu"))
            fid_metric = prepare_fid(real_images, self.device)

        for nfe in nfe_values:
            sample_count = self.cfg.evaluation.num_generated_samples
            reset_peak_gpu_memory(self.device)
            with timer(self.device) as sample_timer:
                images = sampler.generate_for_evaluation(sample_count, nfe)
            elapsed = sample_timer["elapsed"]
            self.results.write(ResultRecord(
                algorithm=sampler.algorithm.name(),
                seed=sampler.seed,
                record_type="sampling",
                epoch=current_epoch,
                nfe=nfe,
                sampling_time=elapsed,
                time_per_image=elapsed / sample_count,
                images_per_second=sample_count / max(elapsed, 1e-8),
                peak_gpu_memory=peak_gpu_memory_mb(self.device),
            ))

            fid_score = None
            if fid_metric is not None:
                fid_score = compute_fid_from_prepared(
                    fid_metric, images, self.device
                )

            is_mean = is_std = None
            if "is" in self.cfg.evaluation.metrics:
                is_mean, is_std = compute_inception_score(images, self.device)

            self.results.write(ResultRecord(
                algorithm=sampler.algorithm.name(),
                seed=sampler.seed,
                record_type="evaluation",
                epoch=current_epoch,
                nfe=nfe,
                fid=fid_score,
                is_mean=is_mean,
                is_std=is_std,
                checkpoint_path=checkpoint_path,
                num_generated_samples=sample_count,
            ))

        if make_plots:
            self._make_plots()

    def _make_plots(self) -> None:
        plot_dir = os.path.join(self.run_dir, "metrics", "plots")
        jsonl_path = self.results.jsonl_path
        plots = (
            (plot_fid_vs_nfe, "fid_vs_nfe.png"),
            (plot_is_vs_nfe, "is_vs_nfe.png"),
            (plot_sampling_time_vs_nfe, "sampling_time_vs_nfe.png"),
            (plot_fid_vs_sampling_time, "fid_vs_sampling_time.png"),
            (plot_loss_vs_epoch, "loss_vs_epoch.png"),
            (plot_training_time_comparison, "training_time.png"),
            (plot_gpu_memory_comparison, "gpu_memory.png"),
        )
        for plot_function, filename in plots:
            plot_function(jsonl_path, os.path.join(plot_dir, filename))
