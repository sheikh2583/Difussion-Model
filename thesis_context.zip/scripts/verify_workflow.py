#!/usr/bin/env python3
"""Cross-platform, non-training verification for the documented workflow."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
os.chdir(PROJECT_ROOT)

REQUIRED_ALGORITHMS = {
    "fm", "fm_lognorm", "mf", "mf_hutchinson", "mf_distill",
    "consistency", "reflow",
}
REQUIRED_DATASETS = {"cifar10", "celeba", "celeba_latent"}


def config_paths() -> tuple[str, ...]:
    """Discover every experiment preset so this verifier cannot go stale."""
    return tuple(
        path.relative_to(PROJECT_ROOT).as_posix()
        for path in sorted((PROJECT_ROOT / "config").rglob("*.json"))
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate imports, configs, datasets, and workflow prerequisites."
    )
    parser.add_argument(
        "--dataset",
        choices=("none", "cifar10", "celeba", "celeba_latent"),
        default="none",
        help="Also load and validate one real dataset batch (may download data).",
    )
    parser.add_argument(
        "--strict-prerequisites",
        action="store_true",
        help=("Fail if teacher checkpoints or Reflow pairs are missing for the "
              "selected dataset; with --dataset none, check both datasets."),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    failures: list[str] = []
    blockers: list[str] = []

    from algorithms import ALGORITHM_REGISTRY
    from config.config import ExperimentConfig
    from data.dataset_registry import DATASET_REGISTRY, get_dataloaders_for_config
    from utils.checkpoints import resolve_checkpoint_reference

    missing_algorithms = REQUIRED_ALGORITHMS - set(ALGORITHM_REGISTRY)
    if missing_algorithms:
        failures.append(f"missing algorithms: {sorted(missing_algorithms)}")
    else:
        extras = sorted(set(ALGORITHM_REGISTRY) - REQUIRED_ALGORITHMS)
        print(f"[OK] algorithms: {sorted(REQUIRED_ALGORITHMS)}")
        if extras:
            print(f"[OK] additional utility algorithms: {extras}")

    if not REQUIRED_DATASETS <= set(DATASET_REGISTRY):
        failures.append(f"dataset registry is incomplete: {sorted(DATASET_REGISTRY)}")
    else:
        print(f"[OK] dataset registry: {', '.join(sorted(REQUIRED_DATASETS))}")

    loaded_configs: dict[str, ExperimentConfig] = {}
    for relative_path in config_paths():
        path = PROJECT_ROOT / relative_path
        if not path.is_file():
            failures.append(f"missing config: {relative_path}")
            continue
        try:
            loaded_configs[relative_path] = ExperimentConfig.load(str(path))
            print(f"[OK] config: {relative_path}")
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as error:
            failures.append(f"invalid config {relative_path}: {error}")

    prerequisite_fields = (
        ("cifar10", "config/mf_distill_full.json", "teacher_checkpoint", "MF-Distill teacher"),
        ("cifar10", "config/consistency_full.json", "teacher_checkpoint", "Consistency teacher"),
        ("cifar10", "config/reflow_full.json", "pairs_path", "Reflow pairs"),
        ("celeba", "config/mf_distill_celeba64.json", "teacher_checkpoint", "CelebA MF-Distill teacher"),
        ("celeba", "config/consistency_celeba64.json", "teacher_checkpoint", "CelebA Consistency teacher"),
        ("celeba", "config/reflow_celeba64.json", "pairs_path", "CelebA Reflow pairs"),
        ("celeba_latent", "config/fm_celeba_latent.json", "codec_checkpoint", "accepted latent codec"),
        ("celeba_latent", "config/mf_distill_celeba_latent.json", "teacher_checkpoint", "latent MF-Distill teacher"),
        ("celeba_latent", "config/consistency_celeba_latent.json", "teacher_checkpoint", "latent Consistency teacher"),
        ("celeba_latent", "config/reflow_celeba_latent.json", "pairs_path", "latent Reflow pairs"),
    )
    for dataset, config_path, field, label in prerequisite_fields:
        if args.dataset != "none" and args.dataset != dataset:
            continue
        cfg = loaded_configs.get(config_path)
        if cfg is None:
            continue
        relative_target = (
            cfg.dataset.codec_checkpoint
            if field == "codec_checkpoint"
            else cfg.algorithm_kwargs.get(field)
        )
        if not relative_target:
            location = (
                "dataset.codec_checkpoint"
                if field == "codec_checkpoint"
                else f"algorithm_kwargs.{field}"
            )
            failures.append(f"{config_path} has no {location}")
            continue
        target = PROJECT_ROOT / relative_target
        if field == "teacher_checkpoint":
            target = resolve_checkpoint_reference(target)
        if target.is_file():
            print(f"[OK] {label}: {target.relative_to(PROJECT_ROOT)}")
        else:
            blockers.append(f"{label} missing: {relative_target}")
            print(f"[BLOCKED] {label}: {relative_target}")

    if args.dataset != "none":
        config_path = {
            "cifar10": "config/smoke_fast.json",
            "celeba": "config/fm_celeba64.json",
            "celeba_latent": "config/fm_celeba_latent.json",
        }[args.dataset]
        cfg = ExperimentConfig.load(str(PROJECT_ROOT / config_path))
        train_loader, _ = get_dataloaders_for_config(cfg)
        images, _ = next(iter(train_loader))
        expected = (3, cfg.dataset.image_size, cfg.dataset.image_size)
        if tuple(images.shape[1:]) != expected:
            failures.append(
                f"{args.dataset} image shape {tuple(images.shape[1:])}, expected {expected}"
            )
        if float(images.min()) < -1.1 or float(images.max()) > 1.1:
            failures.append(
                f"{args.dataset} range [{float(images.min())}, {float(images.max())}]"
            )
        if not failures:
            print(
                f"[OK] {args.dataset} batch: shape={tuple(images.shape)}, "
                f"range=[{float(images.min()):.3f}, {float(images.max()):.3f}]"
            )

    if failures:
        print("\nVerification failed:")
        for failure in failures:
            print(f"  - {failure}")
        return 1
    if blockers and args.strict_prerequisites:
        print("\nCode/config checks passed, but the full workflow is blocked:")
        for blocker in blockers:
            print(f"  - {blocker}")
        return 2

    print("\nWorkflow code and configuration checks passed.")
    if blockers:
        print("Long-running stages remain blocked until these artifacts exist:")
        for blocker in blockers:
            print(f"  - {blocker}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
