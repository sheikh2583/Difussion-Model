#!/usr/bin/env bash
# Train the supported algorithm suite in dependency order.
# Usage:
#   ./scripts/linux/train_all.sh [--dataset cifar10|celeba] [--only ALGORITHM]
#                          [--skip-ALGORITHM] [--mode continue|fresh]
#                          [--batch-size N] [--checkpoint-every N]
#                          [--train-only] [--dry-run]
#                          [--machine-label NAME] [--mf-config FILE]
#                          [--cifar-backbone current|legacy]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"
cd "$PROJECT_ROOT"

PYTHON="$PROJECT_ROOT/venv/bin/python"
if [[ ! -x "$PYTHON" ]]; then
  echo "ERROR: project environment not found. Run ./scripts/linux/setup.sh --yes first." >&2
  exit 1
fi

SKIP_FM=false
SKIP_FM_LOGNORM=false
SKIP_MF=false
SKIP_MF_DISTILL=false
SKIP_CONSISTENCY=false
SKIP_REFLOW=false
ONLY=""
DATASET="cifar10"
DRY_RUN=false
MODE="continue"
BATCH_SIZE=""
CHECKPOINT_EVERY=10
TRAIN_ONLY=false
MACHINE_LABEL=""
MF_CONFIG_OVERRIDE=""
CIFAR_BACKBONE="current"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-fm)          SKIP_FM=true; shift ;;
    --skip-fm-lognorm)  SKIP_FM_LOGNORM=true; shift ;;
    --skip-mf)          SKIP_MF=true; shift ;;
    --skip-mf-distill)  SKIP_MF_DISTILL=true; shift ;;
    --skip-consistency) SKIP_CONSISTENCY=true; shift ;;
    --skip-reflow)      SKIP_REFLOW=true; shift ;;
    --only)
      [[ $# -ge 2 ]] || { echo "ERROR: --only requires a value" >&2; exit 2; }
      ONLY="$2"; shift 2 ;;
    --dataset)
      [[ $# -ge 2 ]] || { echo "ERROR: --dataset requires a value" >&2; exit 2; }
      DATASET="$2"; shift 2 ;;
    --mode)
      [[ $# -ge 2 ]] || { echo "ERROR: --mode requires a value" >&2; exit 2; }
      MODE="$2"; shift 2 ;;
    --batch-size)
      [[ $# -ge 2 ]] || { echo "ERROR: --batch-size requires a value" >&2; exit 2; }
      BATCH_SIZE="$2"; shift 2 ;;
    --checkpoint-every)
      [[ $# -ge 2 ]] || { echo "ERROR: --checkpoint-every requires a value" >&2; exit 2; }
      CHECKPOINT_EVERY="$2"; shift 2 ;;
    --train-only) TRAIN_ONLY=true; shift ;;
    --machine-label)
      [[ $# -ge 2 ]] || { echo "ERROR: --machine-label requires a value" >&2; exit 2; }
      MACHINE_LABEL="$2"; shift 2 ;;
    --mf-config)
      [[ $# -ge 2 ]] || { echo "ERROR: --mf-config requires a value" >&2; exit 2; }
      MF_CONFIG_OVERRIDE="$2"; shift 2 ;;
    --cifar-backbone)
      [[ $# -ge 2 ]] || { echo "ERROR: --cifar-backbone requires a value" >&2; exit 2; }
      CIFAR_BACKBONE="$2"; shift 2 ;;
    --dry-run) DRY_RUN=true; shift ;;
    -h|--help)
      sed -n '2,/^set -euo pipefail/p' "$0" | sed '$d'
      exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; exit 2 ;;
  esac
done

case "$DATASET" in
  cifar10|celeba) ;;
  *) echo "ERROR: --dataset must be cifar10 or celeba" >&2; exit 2 ;;
esac

case "$ONLY" in
  ""|fm|fm_lognorm|mf|mf_distill|consistency|reflow) ;;
  *) echo "ERROR: unknown algorithm for --only: $ONLY" >&2; exit 2 ;;
esac

case "$MODE" in
  continue|fresh) ;;
  *) echo "ERROR: --mode must be continue or fresh" >&2; exit 2 ;;
esac
case "$CIFAR_BACKBONE" in
  current|legacy) ;;
  *) echo "ERROR: --cifar-backbone must be current or legacy" >&2; exit 2 ;;
esac
if [[ "$DATASET" == "celeba" && "$CIFAR_BACKBONE" != "current" ]]; then
  echo "ERROR: --cifar-backbone only applies to --dataset cifar10" >&2
  exit 2
fi

if [[ "$DATASET" == "celeba" ]]; then
  FM_CONFIG="config/fm_celeba64.json"
  FM_LOGNORM_CONFIG="config/fm_lognorm_celeba64.json"
  MF_CONFIG="config/mf_celeba64.json"
  MF_DISTILL_CONFIG="config/mf_distill_celeba64.json"
  CONSISTENCY_CONFIG="config/consistency_celeba64.json"
  REFLOW_CONFIG="config/reflow_celeba64.json"
  FM_RUN_DIR="results/fm_celeba"
  REFLOW_PAIRS="data/reflow_pairs_celeba.pt"
else
  if [[ "$CIFAR_BACKBONE" == "legacy" ]]; then
    FM_CONFIG="config/cifar_legacy/fm.json"
    FM_LOGNORM_CONFIG="config/cifar_legacy/fm_lognorm.json"
    MF_CONFIG="config/cifar_legacy/mf.json"
    MF_DISTILL_CONFIG="config/cifar_legacy/mf_distill.json"
    CONSISTENCY_CONFIG="config/cifar_legacy/consistency.json"
    REFLOW_CONFIG="config/cifar_legacy/reflow.json"
    FM_RUN_DIR="results/fm_legacy_backbone_cifar10"
    REFLOW_PAIRS="data/reflow_pairs_cifar10_legacy_backbone.pt"
  else
    FM_CONFIG="config/fm_full.json"
    FM_LOGNORM_CONFIG="config/fm_lognorm_full.json"
    MF_CONFIG="config/mf_full.json"
    MF_DISTILL_CONFIG="config/mf_distill_full.json"
    CONSISTENCY_CONFIG="config/consistency_full.json"
    REFLOW_CONFIG="config/reflow_full.json"
    FM_RUN_DIR="results/fm_cifar10"
    REFLOW_PAIRS="data/reflow_pairs_cifar10.pt"
  fi
fi

if [[ -n "$MF_CONFIG_OVERRIDE" ]]; then
  if [[ "$CIFAR_BACKBONE" == "legacy" ]]; then
    echo "ERROR: --mf-config cannot be combined with --cifar-backbone legacy" >&2
    exit 2
  fi
  MF_CONFIG="$MF_CONFIG_OVERRIDE"
fi

source scripts/linux/workflow_guard.sh
workflow_guard_start "train_all.sh" "$DRY_RUN" \
  --launcher scripts/linux/train_all.sh \
  --config "$FM_CONFIG" --config "$FM_LOGNORM_CONFIG" \
  --config "$MF_CONFIG" --config "$MF_DISTILL_CONFIG" \
  --config "$CONSISTENCY_CONFIG" --config "$REFLOW_CONFIG"
export DIFFUSION_LIFECYCLE_MODE="$MODE"

FAILED=0

run_training() {
  local algorithm=$1
  local config=$2
  local skip=$3
  [[ "$skip" == false ]] || return 0
  [[ -z "$ONLY" || "$ONLY" == "$algorithm" ]] || return 0
  if [[ ! -f "$config" ]]; then
    echo "[MISSING] config: $config" >&2
    FAILED=1
    return 0
  fi
  workflow_guard_verify_source "$DRY_RUN"
  if [[ "$DRY_RUN" == false ]]; then
    export DIFFUSION_SELECTED_CONFIG_SHA256
    DIFFUSION_SELECTED_CONFIG_SHA256="$(sha256sum "$config" | awk '{print $1}')"
  fi
  export DIFFUSION_CHECKPOINT_SERIES="resolved-by-train.py"
  local command=(
    "$PYTHON" train.py --algorithm "$algorithm" --config "$config"
    --mode "$MODE" --checkpoint-every "$CHECKPOINT_EVERY"
  )
  [[ -z "$BATCH_SIZE" ]] || command+=(--batch-size "$BATCH_SIZE")
  [[ "$TRAIN_ONLY" == false ]] || command+=(--train-only)
  [[ -z "$MACHINE_LABEL" ]] || command+=(--machine-label "$MACHINE_LABEL")
  echo "[PLAN] ${command[*]}"
  if [[ "$DRY_RUN" == false ]]; then
    "${command[@]}"
  fi
}

require_file() {
  local path=$1
  local purpose=$2
  if [[ ! -f "$path" ]]; then
    if [[ "$DRY_RUN" == true ]]; then
      echo "[PLANNED] $purpose: $path"
      return 0
    fi
    echo "[BLOCKED] $purpose: $path" >&2
    FAILED=1
    return 1
  fi
  echo "[OK] $purpose: $path"
}

run_training fm "$FM_CONFIG" "$SKIP_FM"
run_training fm_lognorm "$FM_LOGNORM_CONFIG" "$SKIP_FM_LOGNORM"
run_training mf "$MF_CONFIG" "$SKIP_MF"
if [[ "$DRY_RUN" == true ]]; then
  # Nothing has been created during a dry run, so resolve the path that the
  # selected lifecycle mode would create.
  FM_CKPT="$("$PYTHON" scripts/checkpoint_path.py --run-dir "$FM_RUN_DIR" \
    --class-name FlowMatchingAlgorithm --epoch 100 --planned-mode "$MODE")"
else
  # FM has already run by this point. Resolve the checkpoint that now exists;
  # using --planned-mode fresh here would incorrectly advance to run_(N+1).
  FM_CKPT="$("$PYTHON" scripts/checkpoint_path.py --run-dir "$FM_RUN_DIR" \
    --class-name FlowMatchingAlgorithm --epoch 100)"
fi

if [[ "$SKIP_MF_DISTILL" == false && ( -z "$ONLY" || "$ONLY" == "mf_distill" ) ]]; then
  READY=true
  require_file "$FM_CKPT" "FM teacher checkpoint" || READY=false
  if [[ "$READY" == true || "$DRY_RUN" == true ]]; then
    run_training mf_distill "$MF_DISTILL_CONFIG" false
  fi
fi
if [[ "$SKIP_CONSISTENCY" == false && ( -z "$ONLY" || "$ONLY" == "consistency" ) ]]; then
  READY=true
  require_file "$FM_CKPT" "FM teacher checkpoint" || READY=false
  if [[ "$READY" == true || "$DRY_RUN" == true ]]; then
    run_training consistency "$CONSISTENCY_CONFIG" false
  fi
fi
if [[ "$SKIP_REFLOW" == false && ( -z "$ONLY" || "$ONLY" == "reflow" ) ]]; then
  if [[ "$MODE" == "fresh" && -f "$REFLOW_PAIRS" ]]; then
    HISTORY_DIR="data/history"
    TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
    PAIR_BASENAME="${REFLOW_PAIRS##*/}"
    PAIR_STEM="${PAIR_BASENAME%.pt}"
    ARCHIVED_PAIRS="$HISTORY_DIR/${PAIR_STEM}_${TIMESTAMP}_pid$$.pt"
    echo "[PLAN] Preserve existing Reflow pairs: $REFLOW_PAIRS -> $ARCHIVED_PAIRS"
    if [[ "$DRY_RUN" == false ]]; then
      mkdir -p "$HISTORY_DIR"
      mv -- "$REFLOW_PAIRS" "$ARCHIVED_PAIRS"
    fi
  fi
  if [[ "$MODE" == "fresh" || ! -f "$REFLOW_PAIRS" ]]; then
    READY=true
    require_file "$FM_CKPT" "FM teacher checkpoint" || READY=false
    if [[ "$READY" == true || "$DRY_RUN" == true ]]; then
      workflow_guard_verify_source "$DRY_RUN"
      echo "[PLAN] Generate Reflow pairs: $REFLOW_PAIRS"
      if [[ "$DRY_RUN" == false ]]; then
        "$PYTHON" scripts/generate_reflow_pairs.py \
          --checkpoint "$FM_CKPT" --config "$FM_CONFIG" \
          --n-pairs 50000 --nfe 50 --output "$REFLOW_PAIRS"
      fi
    fi
  fi
  READY=true
  require_file "$REFLOW_PAIRS" "Reflow pairs" || READY=false
  [[ "$READY" == false ]] || run_training reflow "$REFLOW_CONFIG" false
fi

if [[ "$FAILED" -ne 0 ]]; then
  echo "Workflow validation found missing prerequisites." >&2
  exit 1
fi
if [[ "$DRY_RUN" == true ]]; then
  echo "Dry-run validation complete."
else
  echo "Training workflow complete."
fi
