# Linux quickstart

From the repository root:

```bash
chmod +x scripts/linux/*.sh
./scripts/linux/init.sh
./scripts/linux/train_cifar.sh
```

To run CIFAR-10 and then CelebA unattended with one command:

```bash
./scripts/linux/train_all_datasets.sh
```

The launchers run each model sequentially in dependency order. CIFAR-10 uses
the batch-128 exact-JVP MeanFlow configuration. A separate complete terminal
log is saved for every dataset/model pair under a device-specific directory,
with pixel and latent transcripts separated under `pixel/` and `latent/`, for
example `training_logs/nvidia-geforce-rtx-3090-24gb/pixel/`. The latent suite
writes a completed transcript and metadata sidecar for each job but never
stages, commits, or pushes them. Version-control decisions remain with the
operator. Large results, checkpoints, datasets, and generated samples remain
excluded from Git.

GPU launchers share the ownership-checked `results/.lock`, and nested suite
calls inherit its random token without reacquiring it. Each suite also freezes
a content hash of training-relevant source/config inputs and verifies it before
starting the next serialized job. Documentation-only edits are excluded.

The machine label is generated automatically from the OS, hostname, GPU, and
VRAM (for example, `linux-ndag-m-lab-nvidia-geforce-rtx-3090-24gb`). No setup
is required. To use a shorter custom label instead, optionally run:

```bash
export DIFFUSION_MACHINE_LABEL=linux-rtx3090
```

Run `./scripts/linux/train_cifar.sh` again after an interruption. Completed
models are detected, and an interrupted model resumes from its latest completed
10-epoch checkpoint.

For the model-selection menu:

```bash
./scripts/linux/train.sh
```

The menu includes all seven CelebA latent algorithms. They can also be selected
non-interactively, for example:

```bash
./scripts/linux/train.sh --choice celeba_latent:mf --mode continue --yes
./scripts/linux/train.sh --choice celeba_latent:mf_hutchinson --mode fresh --yes
./scripts/linux/train.sh --choice celeba_latent:mf_distill --mode fresh --yes
./scripts/linux/train.sh --choice celeba_latent:consistency --mode fresh --yes
./scripts/linux/train.sh --choice celeba_latent:reflow --mode fresh --yes
```

MF-Distill and Consistency resolve the latent FM teacher automatically. Reflow
also generates latent pairs with `generate_reflow_pairs_latent.py` when needed.

Run the complete dependency-ordered latent workflow through the main launcher:

```bash
./scripts/linux/train.sh --all-latent --mode continue
```

Each completed transcript and metadata sidecar is stored under
`training_logs/<device>/latent/<algorithm>/`. Launchers do not mutate Git.
Schema-2 sidecars preserve transcript hashes plus Git commit/dirty-diff,
frozen source/config, checkpoint-series, and GPU index/UUID/name/memory fields.

Useful checks that do not start training:

```bash
./scripts/linux/train.sh --list
./scripts/linux/train_cifar.sh --dry-run
./scripts/linux/train_all_datasets.sh --dry-run
./scripts/linux/train_celeba_latent.sh --only mf_hutchinson --dry-run
```

For the three independently logged thesis stages, see
`scripts/thesis_runs/README.md`. Each numbered launcher defaults to a fresh,
automatically incremented checkpoint run. The numbered wrappers queue and time
the three stages on the workstation's single GPU.

MF-Hutchinson is supported only by the CelebA latent workflow. There is no
pixel-space Hutchinson preset, training/evaluation reject pixel configs, and
the algorithm is included in the full `--all-latent`/`--only all` workflow.

The CIFAR-10 suite keeps each preset's controlled batch size: 128 for FM,
FM-LN, exact-JVP MF, Consistency, and Reflow; 64 for MF-Distill.

Outputs are stored under `results/<algorithm>_cifar10/` and are ignored by Git.

## Summaries, animations, and dataset bundles

After training finishes, rebuild aggregate tables and dataset-specific outputs:

```bash
./scripts/linux/make_summary.sh
./scripts/linux/generate_cifar10_outputs.sh
./scripts/linux/generate_celeba_outputs.sh
venv/bin/python scripts/package_dataset_bundles.py
./scripts/linux/make_thesis_context.sh
./scripts/linux/refresh_thesis_context.sh --interval 300
```

During active training, rebuild both `THESIS_SUMMARY.md` and the verified ZIP
once without pausing or signaling the trainer:

```bash
./scripts/linux/make_thesis_context.sh --allow-running
```

For an automatically refreshed live snapshot every five minutes:

```bash
./scripts/linux/refresh_thesis_context.sh --allow-running --interval 300
```

The refresh watcher is single-instance. Stop any existing watcher before
restarting it with `--allow-running`. Treat live snapshots as provisional and
run the command again without `--allow-running` after training completes.

These tools use existing metrics, configs, and atomically published checkpoint
archives. They never start, stop, signal, or modify a training process. The
summary helper refuses to run during training unless `--allow-running` is
explicitly supplied; `--dry-run` prints its command without writing outputs.
The animation launchers follow the same `--dry-run` and `--allow-running`
convention. The CelebA launcher creates separate pixel and latent GIFs, then
uses the shared GPU lock while decoding checkpoint samples into RGB grids. If
training is active, `--allow-running` generates metric GIFs only and skips
checkpoint sampling.

`make_thesis_context.sh` produces a compact package for external thesis
discussion. Preview its exact inventory with `--dry-run`; it excludes raw
datasets, checkpoint tensors, checkpoint ZIPs, and FID caches.
It rebuilds and validates the canonical summary by default, requires the
essential implementation files to be Git-tracked, and verifies every archived
member by SHA-256 before replacing `thesis_context.zip`.
Small ignored provenance records (the collaboration plans/decisions, codec
model card, and latent-cache manifest) are included explicitly; ignored binary
weights, tensor caches, datasets, checkpoints, and FID caches remain excluded.
`refresh_thesis_context.sh` runs the CPU-only MF-v3 preflight before each write
cycle, then repeats the complete operation under a single-instance lock. It
retries safely after failures and preserves the last verified ZIP.
The generated `thesis_context.zip` and reporting-generated
`THESIS_SUMMARY.md` are written to the repository root and are Git-trackable.

Run the read-only repository health check at any time:

```bash
venv/bin/python scripts/verify_project_layout.py
```

Before a structural migration, require training to be stopped:

```bash
venv/bin/python scripts/verify_project_layout.py --fail-if-training
```

## Pretrained CelebA latent codec (primary path)

The active latent experiment uses the frozen `CompVis/ldm-celebahq-256`
VQ-f4 codec. It maps 64×64 RGB images to three-channel 16×16 quantized latents;
every algorithm then trains its own randomly initialized latent U-Net.

Train or resume all seven latent algorithms with per-model, GPU-partitioned logs:

```bash
./scripts/linux/train_celeba_latent.sh \
  --machine-label NDAG-M-Lab-RTX3090 \
  --mode continue
```

Use `--dry-run` to preview training without writing logs or starting models.

Preview the exact download and validation commands, then run them:

```bash
./scripts/linux/prepare_pretrained_codec.sh --dry-run \
  --accept-quality-failure \
  --acceptance-reason "User selected the face-specific VQ-f4 latent experiment despite the measured reconstruction ceiling"
./scripts/linux/prepare_pretrained_codec.sh \
  --accept-quality-failure \
  --acceptance-reason "User selected the face-specific VQ-f4 latent experiment despite the measured reconstruction ceiling"
```

On success, continue with the accepted checkpoint:

```bash
venv/bin/python codec/cache_latents.py \
  --codec-path results/codecs/celeba_vq_f4/accepted_codec.pt \
  --celeba-root data/raw --output-dir data/latent_cache \
  --split both --device cuda
```

The preparation launcher resolves `main` to an immutable Hugging Face commit,
records it in `source_manifest.json`, saves a timestamped validation log, and
exits nonzero if a structural or latent-statistics check fails. The explicit
quality override preserves the failed rFID/PSNR values in both the validation
report and accepted checkpoint while allowing the selected latent experiment
to proceed.

## Fresh self-trained CelebA KL-VAE experiment

This launcher starts a new scratch factor-4 KL-VAE run from random initialization.
It never resumes a checkpoint. The default work directory is
`results/codecs/scratch_kl_vae_linux_fresh`; if that directory already contains
a checkpoint, the launcher exits and asks for a new work directory. Existing
VQ codec results and the stopped Windows KL-VAE run remain untouched.

```bash
./scripts/linux/train_scratch_codec.sh --dry-run
./scripts/linux/train_scratch_codec.sh
```

The launcher uses batch 64 for 200 epochs, AdamW at `1e-4`, weight decay
`1e-4`, AMP, gradient clipping `1.0`, and KL warmup `1e-5` to `1e-4` over 20
epochs. It validates every 20 epochs on 5,000 images. Use `--dry-run` to inspect
the exact command before starting and `--help` for safe data, output, and
hyperparameter overrides.

Every scratch-codec launch writes standard `[run]` metadata and a complete
timestamped transcript under the experiment logs. Running
`./scripts/linux/make_summary.sh` discovers it together with every `.log` under
`training_logs/` and `results/`, then writes a generic log catalog and Markdown
index under `results/aggregate/`. This discovery is not tied to a fixed list of
algorithms, so future trainer logs appear automatically.
