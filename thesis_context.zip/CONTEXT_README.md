# Thesis context snapshot

This compact archive is intended for code review and thesis discussion. It contains source, configuration, tests, report material, run provenance, metrics, plots, sample images, and training transcripts. Large model and dataset binaries are deliberately excluded. See `CONTEXT_MANIFEST.json` for the complete inventory and SHA-256 hashes. For the proposed latent-space architecture discussion, begin with `CLAUDE_DISCUSSION_PROMPT.md`.
