# Two-IDE Collaboration Contract: CelebA Latent Extension

This repository is being edited concurrently by Codex and
Antigravity/Claude on the same PC and the same filesystem. Changes made in one
IDE are immediately visible in the other. This phase deliberately does not use
Git as a synchronization, ownership, staging, or handoff mechanism.

## Activation and precedence

This collaboration contract is **opt-in**, not a permanent repository-wide
mode. Its session-start procedure, no-Git rule, no-model-execution rule, static
ownership boundaries, coordination board, and completion standard apply only
when the user explicitly asks to activate the shared-IDE/two-agent workflow for
the current task or phase.

The presence of this file, an old coordination-board entry, or another editor
on the same filesystem does not activate the contract by itself. When the user
has not explicitly activated it, agents follow the user's current request and
the repository's ordinary safety rules; the phase-specific restrictions below
are historical guidance rather than blockers. A direct user instruction may
activate, suspend, replace, or end this contract. Activation is scoped to the
task or phase named by the user and does not silently carry into later work.

## Session start

Every agent must, before writing:

1. Read this file completely.
2. Read its assigned action plan completely:
   - Codex: `CODEX_SELF_TRAINED_CODEC_PLAN.md`
   - Antigravity: `ANTIGRAVITY_PRETRAINED_LATENT_PLAN.md`
3. Read `CROSS_TRACK.md` completely.
4. Inspect the files in its own write set and preserve unexplained user work.
5. Confirm that no file it intends to edit belongs to the other agent.

`PLAN.md` and `scripts/agent_locks.py` are not present in this checkout and are
not part of this phase. Do not recreate them merely to satisfy an obsolete
workflow.

## No-Git rule

During this phase neither agent may run Git mutation commands: no add, commit,
checkout, restore, reset, clean, merge, rebase, stash, or branch operations.
Read-only Git inspection is unnecessary and should normally be skipped. The
user owns all version-control decisions.

## No model-execution rule

Agents implement and statically validate code only. They must not launch:

- model or codec training, including one-step/one-epoch smoke training;
- CUDA sampling, FID/IS evaluation, reconstruction evaluation, or benchmarks;
- pretrained-weight downloads;
- CelebA latent caching;
- Reflow pair generation;
- full GPU smoke tests.

Allowed validation includes compilation, JSON/config parsing, shell syntax,
CPU-only unit tests with tiny synthetic tensors, mocked-codec tests, and command
dry-runs. Commands requiring real weights, CelebA, caches, checkpoints, or the
GPU are written for the operator but not executed by either agent.

## Static, mutually exclusive ownership

Ownership is a hard write boundary for this phase. Reading across boundaries is
allowed. If a required change falls in the other track, post a request to
`CROSS_TRACK.md`; do not edit the file yourself.

### Antigravity owns: pretrained codec and pixel-boundary integration

- `codec/__init__.py`
- `codec/base.py`
- `codec/pretrained_vae.py`
- `codec/codec_factory.py`
- `codec/validate_codec.py`
- `codec/cache_latents.py`
- `evaluation/evaluator.py`
- `sampling/sampler.py`
- `utils/results.py`
- `scripts/smoke_latent.py`
- Antigravity-specific tests and dependency declarations
- `ANTIGRAVITY_PRETRAINED_LATENT_PLAN.md`

### Codex owns: scratch codec and latent-native training side

- `codec/scratch_vae.py`
- `codec/train_scratch_vae.py`
- `data/celeba_latent.py`
- `data/dataset_registry.py`
- `config/config.py`
- `config/*_celeba_latent.json`
- `algorithms/base.py`
- `algorithms/flow_matching.py`
- `algorithms/flow_matching_lognorm.py`
- `algorithms/mean_flow.py`
- `algorithms/mean_flow_distill.py`
- `algorithms/consistency.py`
- `algorithms/reflow.py`
- `scripts/generate_reflow_pairs_latent.py`
- Codex-specific tests
- `CODEX_SELF_TRAINED_CODEC_PLAN.md`

### Shared coordination files

- `AGENTS.md` is frozen after this split unless the user requests another
  coordination change.
- `CROSS_TRACK.md` is append-only for both agents.
- No agent may edit or regenerate user results, datasets, checkpoints,
  `THESIS_SUMMARY.md`, or `thesis_context.zip` during implementation.

## Agreed cross-track interfaces

These contracts allow both tracks to work without editing each other's files.

### Codec API

`codec/base.py`, owned by Antigravity, defines the common contract. Both codec
backends expose:

```python
latent_channels: int          # 3 for accepted VQ-f4; 4 for historical codecs
spatial_factor: int           # 4 for the accepted pretrained primary design
pixel_size: int               # 64
posterior_mode: str           # "mean"
stats_frozen: bool
latent_mean: Tensor           # shape (1, latent_channels, 1, 1)
latent_std: Tensor            # shape (1, latent_channels, 1, 1)

encode_mean(images) -> Tensor
decode(scaled_latents) -> Tensor
normalise(scaled_latents) -> Tensor
denormalise(normalised_latents) -> Tensor
decode_normalised(normalised_latents) -> Tensor
compute_and_freeze_stats(dataloader, device) -> None
save(path) -> None
```

Checkpoint metadata contains at least:

```text
schema_version, codec_type, codec_source, codec_source_revision,
codec_weights_sha256, latent_channels, spatial_factor, pixel_size,
posterior_mode, native_scaling_factor, stats_frozen, latent_mean,
latent_std, dataset, image_size
```

The primary codec is the frozen face-specific `CompVis/ldm-celebahq-256`
VQ-f4 model. Its deterministic codebook-quantized output maps 64x64 RGB images
to three-channel 16x16 latents. The factor-8 SD VAE and completed scratch VAE
both failed the local reconstruction gate and remain rejected historical
evidence. Codec metadata and cache manifests are authoritative.

### Latent cache contract

- Pixel input: `(B, 3, 64, 64)` in `[-1, 1]`.
- Cached tensor: `(N, 3, 16, 16)` float32, normalized with frozen training-set
  per-channel statistics.
- Cache identity uses the codec checkpoint/content digest, split, posterior
  mode, normalization schema, and preprocessing identity. It must not depend
  only on an absolute path.
- Multiple codec caches may coexist. The dataset resolves the exact matching
  cache and rejects ambiguity or metadata/hash mismatch.
- `CelebALatentDataset.__getitem__()` returns `(latent, dummy_label)` because
  the current trainer iterates as `for batch, _ in train_loader`.

### Sampling and evaluation contract

- Algorithms operate on normalized state tensors and return normalized latent
  tensors for latent configs.
- Latent outputs are unbounded and must never be clamped to `[-1, 1]`.
  Existing pixel configs retain their current clamp behavior.
- The evaluator decodes generated latents in bounded batches before FID/IS.
- FID reference images remain raw CelebA validation RGB pixels, 64x64x3, with
  5,000 samples and a separate latent-experiment cache filename.
- NFE timing measures generative-backbone evaluations. Decoder time is recorded
  separately.
- Four-channel tensors are never passed directly to `save_image()`.

### Experiment isolation

- CIFAR-10 is untouched.
- Existing pixel-space configs, results, checkpoints, and metrics are untouched.
- Latent dataset name is `celeba_latent`.
- Latent config `experiment_name` is only the algorithm key, producing paths
  such as `results/fm_celeba_latent`.
- Latent and pixel results are never silently merged into one ranking.
- All existing configs must continue to parse and preserve behavior.

## Communication

`CROSS_TRACK.md` is append-only. Add a dated entry under the current latent
phase using one of these types:

- `READY`: a promised interface now exists and is statically validated.
- `NEEDS_INTERFACE`: the other track must provide or clarify a contract.
- `DEFECT`: a problem was found in the other track's owned file.
- `HANDOFF`: owned work is intentionally left incomplete.
- `RESOLVED`: closes a prior item.

Every entry must state agent, paths, exact need/result, and acceptance criteria.
Do not use the board for generic progress narration.

## Concurrent execution sequence

1. Antigravity first creates and CPU-validates only the common codec contract
   in `codec/base.py`, then posts `READY`.
2. While that small interface is being established, Codex may work on config,
   dataset, algorithm-finalization, Reflow scaffolding, and scratch internals
   that do not yet import the base class.
3. After the codec-contract `READY`, both tracks proceed concurrently inside
   their exclusive write sets. Codex binds `ScratchKLVAE` to the published
   contract; Antigravity completes factory, pretrained codec, caching, and
   pixel-boundary integration.
4. Each track posts a final `READY` containing its changed paths and exact
   CPU/static checks. Neither agent edits the other track to repair an
   integration failure.
5. Once both final `READY` entries exist, Antigravity may run only the mocked
   CPU/static smoke mode. Any real codec/cache/CUDA smoke remains operator-only.

## Operator order after both tracks are ready

The agents document these commands but do not run them:

1. Download and validate the frozen face-specific pretrained VQ-f4 codec.
2. Do not resume the rejected scratch-codec run; it is historical evidence,
   not a fallback for the primary experiment.
3. Cache train and validation latents using the accepted codec.
4. Run the full latent smoke test; stop on any failure.
5. Train latent FM first. FM-LN and ordinary MF may run independently when the
   GPU is available.
6. Generate latent Reflow pairs from the completed latent FM checkpoint.
7. Train MF-Distill and Consistency after latent FM; train Reflow after pairs
   exist.

Every `train.py` command must include `--algorithm <key>`, `--config <path>`,
and an explicit lifecycle such as `--mode fresh`. GPU jobs must be serialized
by the operator; “may run independently” is a dependency statement, not
permission for simultaneous jobs on one GPU.

## Completion standard

Each agent finishes only when its owned scope compiles, focused CPU/synthetic
tests pass, existing config parsing remains valid where applicable, operator
commands are documented but unexecuted, and any unresolved dependency is
recorded in `CROSS_TRACK.md`.
